SHEGER MINERAL ENTERPRISE — PREMIUM WEB APP
Demo login: sheger / 1234

NETLIFY:
1. Extract this ZIP.
2. Open https://app.netlify.com/drop
3. Drag the extracted folder into Netlify Drop.
4. Netlify gives you the live .netlify.app URL.

This version is a browser prototype using localStorage. Production deployment
needs a real backend/database and server-side authentication for secure multi-user use.
